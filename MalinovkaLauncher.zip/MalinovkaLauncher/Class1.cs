namespace MalinovkaLauncher;

internal class Class1
{
}
