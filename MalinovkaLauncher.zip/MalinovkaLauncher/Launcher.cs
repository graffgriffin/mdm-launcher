using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using Newtonsoft.Json;
using SampQueryApi;

namespace MalinovkaLauncher;

public class Launcher : Form
{
	internal class LauncherData
	{
		public string[] banned_files { get; set; } = new string[1] { "null" };

		public string Address { get; set; } = "46.174.55.30";

		public string Port { get; set; } = "7777";

		public string Password { get; set; } = "nV5Wp4WaUoI9NchpoWCJLDwQ";

		public string Password_ { get; set; } = "nV5Wp4WaUoI9NchpoWCJLDwQ";

		public string launcher_ver { get; set; }

		public int launcher_ver_number { get; set; }

		public int launcher_allow_access { get; set; }

		public int launcher_voice_update { get; set; }
	}

	internal class DL_Files
	{
		public string[] folders { get; set; } = new string[1] { "null" };

		public string[] files_name { get; set; } = new string[1] { "null" };

		public string[] files_hash { get; set; } = new string[1] { "null" };

		public string[] files_url { get; set; } = new string[1] { "null" };
	}

	internal class LauncherSettings
	{
		public string lnickname { get; set; }

		public int last_check_files { get; set; }
	}

	protected Process[] processList;

	protected Process[] processListGTA;

	private const int GWL_EXSTYLE = -20;

	private const int WS_EX_TOOLWINDOW = 128;

	private Point mouseOffset;

	private bool isMouseDown;

	private bool is_gta_sa_exe;

	private bool is_limit_adjuster_asi;

	private bool is_limit_adjuster_ini;

	private bool is_mdm_core;

	private bool is_fastman_asi;

	private bool is_fastman_ini;

	private bool is_mdm_asi;

	private bool is_loader_asi;

	private bool is_minhook_dll;

	private bool installgame;

	private bool dl_files_ready;

	private bool isGameStarted;

	private string gamedownload = "https://mdm-serv.ru/launcher/r3/game_crmp.zip";

	private string GameFolder = "game_crmp";

	private string ZipFileName = "game_crmp.zip";

	private string launcher_json_info = "http://46.174.55.30/launcher/launcher.json";

	private string dl_files_info_old = "http://46.174.55.30/launcher/files_r1.json";

	private string dl_files_info_new = "http://46.174.55.30/launcher/files_r3.json";

	private int old_label_width;

	private string processor_id = "";

	private string motherboard = "";

	private string fileSettingsName = "launcher_settings.json";

	private int launcher_vnum = 37;

	private string[] blacklist = new string[1] { "nil" };

	private string[] modules_array = new string[1] { "nil" };

	private WebClient webClient = new WebClient();

	private Stopwatch sw = new Stopwatch();

	private LauncherData JsonData;

	private DL_Files JsonFilesData;

	private LauncherSettings JsonFSettings;

	private IContainer components;

	private TextBox NickName;

	private Label label3;

	private LinkLabel Connect;

	private LinkLabel SiteLink;

	private LinkLabel ForumLink;

	private LinkLabel VKLink;

	private LinkLabel DonateLink;

	private LinkLabel CloseLauncher;

	private Label Dlabel;

	private ProgressBar DProgress;

	private Label SpeedDownload;

	private Label GameReady;

	private Button DownloadGame;

	private Button CancelDownloading;

	private Label LauncherInfoError;

	private Button button1;

	private Label DopDL;

	[DllImport("user32.dll")]
	private static extern int SetWindowLong(IntPtr window, int index, int value);

	[DllImport("user32.dll")]
	private static extern int GetWindowLong(IntPtr window, int index);

	public Launcher()
	{
		processList = Process.GetProcessesByName("MalinovkaLauncher");
		for (int i = 0; i != processList.Length; i++)
		{
			if (processList[i].Id != Process.GetCurrentProcess().Id)
			{
				processList[i].Kill();
			}
		}
		InitializeComponent();
	}

	private static string CaesarDecode(string s, int key)
	{
		string text = "abcdefghijklmnopqrstuvwxyz";
		int length = text.Length;
		string text2 = "";
		for (int i = 0; i < s.Length; i++)
		{
			text2 = ((!int.TryParse(s[i].ToString(), out var _)) ? ((s.ToUpper()[i] != s[i]) ? (text2 + text[((text.IndexOf(s[i]) - key) % length + length) % length]) : (text2 + text.ToUpper()[((text.IndexOf(s.ToLower()[i]) - key) % length + length) % length])) : (text2 + s[i]));
		}
		return text2;
	}

	private void DownLoadFileByWebRequest(string urlAddress, string filePath)
	{
		try
		{
			HttpWebRequest obj = (HttpWebRequest)WebRequest.Create(urlAddress);
			obj.Timeout = 30000;
			Stream responseStream = ((HttpWebResponse)obj.GetResponse()).GetResponseStream();
			if (File.Exists(filePath))
			{
				File.Delete(filePath);
			}
			FileStream fileStream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
			byte[] buffer = new byte[102400];
			int num = 0;
			while ((num = responseStream.Read(buffer, 0, 10400)) > 0)
			{
				fileStream.Write(buffer, 0, num);
				fileStream.Flush();
			}
			fileStream.Close();
			responseStream.Close();
		}
		catch
		{
		}
		finally
		{
			Process.Start(Application.StartupPath + "\\Updater.exe");
			Close();
		}
	}

	private void DownloadUpdate_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
	{
		if (e.Error == null)
		{
			Process.Start(Application.StartupPath + "\\Updater.exe");
			Close();
		}
		else
		{
			MessageBox.Show(Convert.ToString(e.Error), "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	private void LoadLauncherInfo()
	{
		try
		{
			using (WebClient webClient = new WebClient())
			{
				try
				{
					ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
					string text = webClient.DownloadString(launcher_json_info);
					JsonData = JsonConvert.DeserializeObject<LauncherData>(text);
				}
				catch (Exception ex)
				{
					MessageBox.Show("Произошла ошибка при загрузке данных (" + ex.Message + ")", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				if (JsonData.launcher_ver_number > launcher_vnum)
				{
					ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
					WebClient obj = new WebClient();
					Uri address = new Uri("https://malinovka-dm.com/download/new/Updater.exe");
					obj.DownloadFileAsync(address, Application.StartupPath + "\\Updater.exe");
					obj.DownloadFileCompleted += DownloadUpdate_DownloadFileCompleted;
					if (File.Exists(Application.StartupPath + "\\Updater.exe"))
					{
						try
						{
							File.Delete(Application.StartupPath + "\\Updater.exe");
						}
						catch
						{
						}
					}
					ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
					DownLoadFileByWebRequest("https://malinovka-dm.com/download/new/Updater.exe", Application.StartupPath + "\\Updater.exe");
				}
				UpdateOnline();
			}
			try
			{
				if (Directory.Exists(Application.StartupPath + "\\game_crmp"))
				{
					GameFolder = "game_crmp";
				}
				else if (Directory.Exists(Application.StartupPath + "\\Game"))
				{
					GameFolder = "Game";
				}
				using WebClient webClient2 = new WebClient();
				string text2 = "";
				text2 = ((!(GameFolder == "Game")) ? dl_files_info_new : dl_files_info_old);
				ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
				string text3 = webClient2.DownloadString(text2);
				JsonFilesData = JsonConvert.DeserializeObject<DL_Files>(text3);
			}
			catch
			{
				JsonFilesData = new DL_Files();
			}
			try
			{
				if (JsonData.launcher_voice_update == 1)
				{
					if (File.Exists(Application.StartupPath + "\\" + GameFolder + "\\cef\\plugins\\sampvoice.dll"))
					{
						if (File.Exists(Application.StartupPath + "\\" + GameFolder + "\\cef\\plugins\\sampvoice.unuse"))
						{
							File.Delete(Application.StartupPath + "\\" + GameFolder + "\\cef\\plugins\\sampvoice.unuse");
						}
						File.Move(Application.StartupPath + "\\" + GameFolder + "\\cef\\plugins\\sampvoice.dll", Application.StartupPath + "\\" + GameFolder + "\\cef\\plugins\\sampvoice.unuse");
					}
					if (File.Exists(Application.StartupPath + "\\" + GameFolder + "\\sampvoice.unuse"))
					{
						File.Move(Application.StartupPath + "\\" + GameFolder + "\\sampvoice.unuse", Application.StartupPath + "\\" + GameFolder + "\\sampvoice.asi");
					}
					if (File.Exists(Application.StartupPath + "\\" + GameFolder + "\\audio.asi"))
					{
						if (File.Exists(Application.StartupPath + "\\" + GameFolder + "\\audio.unuse"))
						{
							File.Delete(Application.StartupPath + "\\" + GameFolder + "\\audio.unuse");
						}
						File.Move(Application.StartupPath + "\\" + GameFolder + "\\audio.asi", Application.StartupPath + "\\" + GameFolder + "\\audio.unuse");
					}
				}
				else
				{
					if (File.Exists(Application.StartupPath + "\\" + GameFolder + "\\cef\\plugins\\sampvoice.unuse"))
					{
						File.Move(Application.StartupPath + "\\" + GameFolder + "\\cef\\plugins\\sampvoice.unuse", Application.StartupPath + "\\" + GameFolder + "\\cef\\plugins\\sampvoice.dll");
					}
					if (File.Exists(Application.StartupPath + "\\" + GameFolder + "\\sampvoice.asi"))
					{
						File.Move(Application.StartupPath + "\\" + GameFolder + "\\sampvoice.asi", Application.StartupPath + "\\" + GameFolder + "\\sampvoice.unuse");
					}
				}
			}
			catch (Exception)
			{
			}
		}
		catch
		{
			JsonData = new LauncherData
			{
				Address = "46.174.55.30",
				Port = "7777",
				Password = "nV5Wp4WaUoI9NchpoWCJLDwQ"
			};
			JsonFilesData = new DL_Files();
			try
			{
				UpdateOnline();
			}
			catch
			{
			}
			LauncherInfoError.Visible = true;
		}
	}

	private void Launcher_Load(object sender, EventArgs e)
	{
		LoadLauncherInfo();
		NickName.BorderStyle = BorderStyle.None;
		Connect.BackColor = Color.Transparent;
		SiteLink.BackColor = Color.Transparent;
		ForumLink.BackColor = Color.Transparent;
		VKLink.BackColor = Color.Transparent;
		DonateLink.BackColor = Color.Transparent;
		CloseLauncher.BackColor = Color.Transparent;
		SpeedDownload.BackColor = Color.Transparent;
		Dlabel.BackColor = Color.Transparent;
		GameReady.BackColor = Color.Transparent;
		DopDL.BackColor = Color.Transparent;
		old_label_width = Dlabel.Width;
		try
		{
			foreach (ManagementObject item in new ManagementObjectSearcher("Select * From Win32_processor").Get())
			{
				processor_id = item["ProcessorID"].ToString();
			}
			string arg = "localhost";
			ManagementScope managementScope = new ManagementScope($"\\\\{arg}\\root\\CIMV2", null);
			managementScope.Connect();
			ObjectQuery query = new ObjectQuery("SELECT UUID FROM Win32_ComputerSystemProduct");
			foreach (ManagementObject item2 in new ManagementObjectSearcher(managementScope, query).Get())
			{
				motherboard = item2["UUID"].ToString();
			}
		}
		catch
		{
			if (motherboard.Length == 0)
			{
				motherboard = "SpecialUUID";
				processor_id = "SpecialProcessorID";
			}
		}
		if (!File.Exists(Application.StartupPath + "\\" + fileSettingsName))
		{
			LauncherSettings launcherSettings = new LauncherSettings
			{
				lnickname = (string)Registry.GetValue("HKEY_CURRENT_USER\\Software\\SAMP", "PlayerName", ""),
				last_check_files = 0
			};
			if (launcherSettings.lnickname.Length == 0)
			{
				launcherSettings.lnickname = "Введите никнейм";
			}
			string contents = JsonConvert.SerializeObject((object)launcherSettings, (Formatting)1);
			File.WriteAllText(Application.StartupPath + "\\" + fileSettingsName, contents);
		}
		string text = File.ReadAllText(Application.StartupPath + "\\" + fileSettingsName);
		JsonFSettings = JsonConvert.DeserializeObject<LauncherSettings>(text);
		NickName.Text = JsonFSettings.lnickname;
		if (JsonFSettings.last_check_files == 0)
		{
			JsonFSettings.lnickname = JsonFSettings.lnickname;
			JsonFSettings.last_check_files = 1;
			string contents2 = JsonConvert.SerializeObject((object)JsonFSettings, (Formatting)1);
			File.WriteAllText(Application.StartupPath + "\\" + fileSettingsName, contents2);
		}
		if ((int)(DateTime.Now.ToUniversalTime() - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds - JsonFSettings.last_check_files < 127800)
		{
			dl_files_ready = true;
		}
		if (Directory.Exists(Application.StartupPath + "\\game_crmp"))
		{
			GameFolder = "game_crmp";
		}
		else if (Directory.Exists(Application.StartupPath + "\\Game"))
		{
			GameFolder = "Game";
		}
		if (!File.Exists(Application.StartupPath + "\\" + GameFolder + "\\gameinstalled"))
		{
			installgame = false;
			DownloadGame.Visible = true;
			if (MessageBox.Show("Игра повреждена или не установлена.\nЖелаете установить игру?", "Malinovka Launcher", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				DownLoadGame();
			}
		}
		else if (File.Exists(Application.StartupPath + "\\" + GameFolder + "\\_loader.asi"))
		{
			installgame = false;
			DownloadGame.Visible = true;
			if (MessageBox.Show("Сборка игры была изменена. Необходимо полностью переустановить игру", "Malinovka Launcher", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				DownLoadGame();
			}
		}
		else
		{
			installgame = true;
			DProgress.Value = 100;
		}
	}

	private void DownLoadGame()
	{
		DownloadGame.Visible = false;
		CancelDownloading.Visible = true;
		Dlabel.Visible = true;
		SpeedDownload.Visible = true;
		if (File.Exists(Application.StartupPath + "\\" + ZipFileName))
		{
			File.Delete(Application.StartupPath + "\\" + ZipFileName);
		}
		if (Directory.Exists(Application.StartupPath + "\\game_crmp"))
		{
			try
			{
				Directory.Delete(Application.StartupPath + "\\game_crmp", recursive: true);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}
		webClient = new WebClient();
		webClient.DownloadFileCompleted += Completed;
		webClient.DownloadProgressChanged += ProgressChanged;
		Uri address = new Uri(gamedownload);
		sw.Start();
		try
		{
			ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
			webClient.DownloadFileAsync(address, Application.StartupPath + "\\" + ZipFileName);
		}
		catch (Exception ex2)
		{
			MessageBox.Show("[#1]" + ex2.Message);
		}
	}

	private void ProgressChanged(object sender, DownloadProgressChangedEventArgs e)
	{
		SpeedDownload.Text = string.Format("{0} МБ/с", ((double)e.BytesReceived / 1024.0 / 1024.0 / sw.Elapsed.TotalSeconds).ToString("0.00"));
		DProgress.Value = e.ProgressPercentage;
		Dlabel.Text = string.Format("{0} из {1} МБ", ((double)e.BytesReceived / 1024.0 / 1024.0).ToString("0"), ((double)e.TotalBytesToReceive / 1024.0 / 1024.0).ToString("0"));
	}

	private void Completed(object sender, AsyncCompletedEventArgs e)
	{
		sw.Reset();
		if (e.Cancelled)
		{
			if (File.Exists(Application.StartupPath + "\\" + ZipFileName))
			{
				File.Delete(Application.StartupPath + "\\" + ZipFileName);
			}
			DownloadGame.Visible = true;
			CancelDownloading.Visible = false;
			Dlabel.Visible = false;
			SpeedDownload.Visible = false;
			MessageBox.Show("Установка игры отменена", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			webClient = null;
		}
		else if (e.Error == null)
		{
			GameReady.Text = "Распаковка игры!";
			GameReady.Visible = true;
			CancelDownloading.Visible = false;
			Dlabel.Visible = false;
			SpeedDownload.Visible = false;
			if (!Directory.Exists(Application.StartupPath + "\\game_crmp"))
			{
				Directory.CreateDirectory(Application.StartupPath + "\\game_crmp");
			}
			try
			{
				string sourceArchiveFileName = Directory.GetCurrentDirectory() + "\\" + ZipFileName;
				string destinationDirectoryName = Directory.GetCurrentDirectory() + "\\game_crmp";
				ZipFile.ExtractToDirectory(sourceArchiveFileName, destinationDirectoryName);
				File.Delete(Application.StartupPath + "\\" + ZipFileName);
			}
			catch (Exception ex)
			{
				MessageBox.Show("[#2] " + ex.Message, "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				Close();
			}
			installgame = true;
			GameReady.Text = "Можно играть!";
		}
		else
		{
			switch (MessageBox.Show(Convert.ToString("При загрузке возникла ошибка:\n\n" + e.Error?.ToString() + "\n\nНажмите \"Повторить\", чтобы возобносить загрузку\nНажмите \"Отмена\", чтобы закрыть лаунчер"), "Malinovka Launcher", MessageBoxButtons.RetryCancel, MessageBoxIcon.Hand))
			{
			case DialogResult.Retry:
				DownLoadGame();
				break;
			case DialogResult.Cancel:
				Close();
				break;
			}
		}
	}

	public static string ComputeMD5Checksum(string path)
	{
		string result = "nil";
		try
		{
			using FileStream inputStream = File.OpenRead(path);
			using MD5CryptoServiceProvider mD5CryptoServiceProvider = new MD5CryptoServiceProvider();
			result = BitConverter.ToString(mD5CryptoServiceProvider.ComputeHash(inputStream)).Replace("-", string.Empty);
		}
		catch (IOException)
		{
		}
		return result;
	}

	private void CheckDirectoryFromBannedFilesWhileGameIsStarted(DirectoryInfo path)
	{
		FileInfo[] files = path.GetFiles();
		foreach (FileInfo fileInfo in files)
		{
			string text = ComputeMD5Checksum(path?.ToString() + "\\" + fileInfo.Name);
			string[] banned_files = JsonData.banned_files;
			foreach (string text2 in banned_files)
			{
				if (!(text.ToLower() == text2))
				{
					continue;
				}
				try
				{
					isGameStarted = false;
					processList = Process.GetProcessesByName("gta_sa");
					for (int k = 0; k != processList.Length; k++)
					{
						if (processList[k].Id != 6852)
						{
							processList[k].Kill();
						}
					}
					string text3 = new WebClient().DownloadString("https://api.ipify.org");
					Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
					IPEndPoint remoteEP = new IPEndPoint(IPAddress.Parse(JsonData.Address), 7779);
					socket.Connect(remoteEP);
					byte[] bytes = Encoding.UTF8.GetBytes("CHFWG | " + NickName.Text + "|" + text3 + "|" + fileInfo.Name + "|" + text);
					_ = new byte[512];
					socket.Send(bytes, 0, bytes.Length, SocketFlags.None);
					socket.Close();
					if (MessageBox.Show("Обнаружена установка запрещенного ПО\nЕсли произошла ошибка - обратитесь в тех.поддержку (vk.com/mdmserv)", "GTA SA:MP", MessageBoxButtons.OK, MessageBoxIcon.Hand, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification) == DialogResult.OK)
					{
						Close();
					}
				}
				catch
				{
				}
				break;
			}
		}
	}

	private void CheckDirectoryFromBannedFiles(DirectoryInfo path)
	{
		FileInfo[] files = path.GetFiles();
		foreach (FileInfo fileInfo in files)
		{
			string text = ComputeMD5Checksum(path?.ToString() + "\\" + fileInfo.Name);
			string[] banned_files = JsonData.banned_files;
			foreach (string text2 in banned_files)
			{
				if (!(text.ToLower() == text2))
				{
					continue;
				}
				try
				{
					File.Delete(path?.ToString() + "\\" + fileInfo.Name);
					try
					{
						ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
						string url = "https://malinovka-dm.com/launcher/log_banned_files.php?nick=" + NickName.Text + "&file=" + fileInfo.Name + "&hash=" + text.ToLower();
						string result = "";
						Task.Run(delegate
						{
							using WebResponse webResponse = ((HttpWebRequest)WebRequest.Create(url)).GetResponse();
							using StreamReader streamReader = new StreamReader(webResponse.GetResponseStream(), Encoding.UTF8);
							result = streamReader.ReadToEnd();
						}).ContinueWith(delegate
						{
						});
					}
					catch
					{
					}
				}
				catch
				{
					processList = Process.GetProcessesByName("gta_sa");
					for (int num = 0; num != processList.Length; num++)
					{
						if (processList[num].Id != 6852)
						{
							processList[num].Kill();
						}
					}
					string text3 = new WebClient().DownloadString("https://api.ipify.org");
					Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
					IPEndPoint remoteEP = new IPEndPoint(IPAddress.Parse(JsonData.Address), 7779);
					socket.Connect(remoteEP);
					byte[] bytes = Encoding.UTF8.GetBytes("CHFWG | " + NickName.Text + "|" + text3 + "|" + fileInfo.Name + " (read only)|" + text);
					_ = new byte[512];
					socket.Send(bytes, 0, bytes.Length, SocketFlags.None);
					socket.Close();
					if (MessageBox.Show("Обнаружена установка запрещенного ПО\nЕсли произошла ошибка - обратитесь в тех.поддержку (vk.com/mdmserv)", "GTA SA:MP", MessageBoxButtons.OK, MessageBoxIcon.Hand, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification) == DialogResult.OK)
					{
						Close();
					}
				}
			}
		}
	}

	private void label3_Click(object sender, EventArgs e)
	{
		UpdateOnline();
	}

	private void Launcher_MouseDown(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			int num = -e.X - SystemInformation.FrameBorderSize.Width;
			int num2 = -e.Y - SystemInformation.CaptionHeight - SystemInformation.FrameBorderSize.Height;
			mouseOffset = new Point(num, num2);
			isMouseDown = true;
		}
	}

	private void Launcher_MouseMove(object sender, MouseEventArgs e)
	{
		if (isMouseDown)
		{
			Point mousePosition = Control.MousePosition;
			mousePosition.Offset(mouseOffset.X, mouseOffset.Y);
			base.Location = mousePosition;
		}
	}

	private void Launcher_MouseUp(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			isMouseDown = false;
		}
	}

	private async void Connect_MouseClick(object sender, MouseEventArgs e)
	{
		if (dl_files_ready)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(Application.StartupPath + "\\" + GameFolder);
			DirectoryInfo path = new DirectoryInfo(Application.StartupPath + "\\" + GameFolder + "\\cleo");
			DirectoryInfo path2 = new DirectoryInfo(Application.StartupPath + "\\" + GameFolder + "\\moonloader");
			DirectoryInfo path3 = new DirectoryInfo(Application.StartupPath + "\\" + GameFolder + "\\sampfuncs");
			if (Directory.Exists(Application.StartupPath + "\\" + GameFolder))
			{
				CheckDirectoryFromBannedFiles(directoryInfo);
			}
			if (Directory.Exists(Application.StartupPath + "\\" + GameFolder + "\\cleo"))
			{
				CheckDirectoryFromBannedFiles(path);
			}
			if (Directory.Exists(Application.StartupPath + "\\" + GameFolder + "\\moonloader"))
			{
				CheckDirectoryFromBannedFiles(path2);
			}
			if (Directory.Exists(Application.StartupPath + "\\" + GameFolder + "\\sampfuncs"))
			{
				CheckDirectoryFromBannedFiles(path3);
			}
			if (Directory.Exists(Application.StartupPath + "\\" + GameFolder + "\\modloader"))
			{
				Directory.Delete(Application.StartupPath + "\\" + GameFolder + "\\modloader", recursive: true);
			}
			if (GameFolder == "Game")
			{
				FileInfo[] files = directoryInfo.GetFiles();
				foreach (FileInfo obj in files)
				{
					if (obj.Name == "gta_sa.exe")
					{
						is_gta_sa_exe = true;
					}
					if (obj.Name == "III.VC.SA.LimitAdjuster.asi")
					{
						is_limit_adjuster_asi = true;
					}
					if (obj.Name == "III.VC.SA.LimitAdjuster.ini")
					{
						is_limit_adjuster_ini = true;
					}
					if (obj.Name == "mdm_core.asi")
					{
						is_mdm_core = true;
					}
				}
			}
			else if (GameFolder == "game_crmp")
			{
				FileInfo[] files = directoryInfo.GetFiles();
				foreach (FileInfo obj2 in files)
				{
					if (obj2.Name == "gta_sa.exe")
					{
						is_gta_sa_exe = true;
					}
					if (obj2.Name == "III.VC.SA.LimitAdjuster.asi")
					{
						is_limit_adjuster_asi = true;
					}
					if (obj2.Name == "III.VC.SA.LimitAdjuster.ini")
					{
						is_limit_adjuster_ini = true;
					}
					if (obj2.Name == "$fastman92limitAdjuster.asi")
					{
						is_fastman_asi = true;
					}
					if (obj2.Name == "fastman92limitAdjuster_GTASA.ini")
					{
						is_fastman_ini = true;
					}
					if (obj2.Name == "MDM.asi")
					{
						is_mdm_asi = true;
					}
					if (obj2.Name == "MinHook.x86.dll")
					{
						is_minhook_dll = true;
					}
					if (obj2.Name == "mdm_drp.asi")
					{
						is_mdm_core = true;
					}
				}
			}
			if (GameFolder == "Game")
			{
				if (!is_gta_sa_exe)
				{
					MessageBox.Show("Ошибка #2 (не найден запускаемый файл gta_sa.exe)", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				if (!is_limit_adjuster_asi)
				{
					MessageBox.Show("Ошибка #4 (не найден необходимый файл III.VC.SA.LimitAdjuster.asi)", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				if (!is_limit_adjuster_ini)
				{
					MessageBox.Show("Ошибка #5 (не найден необходимый файл III.VC.SA.LimitAdjuster.ini)", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				if (!is_mdm_core)
				{
					MessageBox.Show("Ошибка #6 (не найден необходимый файл mdm_core.asi)", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			else
			{
				if (!is_gta_sa_exe)
				{
					MessageBox.Show("Ошибка #2 (не найден запускаемый файл gta_sa.exe)", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				if (!is_limit_adjuster_asi)
				{
					MessageBox.Show("Ошибка #4 (не найден необходимый файл III.VC.SA.LimitAdjuster.asi)", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				if (!is_limit_adjuster_ini)
				{
					MessageBox.Show("Ошибка #5 (не найден необходимый файл III.VC.SA.LimitAdjuster.ini)", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				if (!is_mdm_core)
				{
					MessageBox.Show("Ошибка #6 (не найден необходимый файл mdm_drp.asi)", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				if (!is_fastman_asi)
				{
					MessageBox.Show("Ошибка #7 (не найден необходимый файл $fastman92limitAdjuster.asi)", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				if (!is_fastman_ini)
				{
					MessageBox.Show("Ошибка #8 (не найден необходимый файл fastman92limitAdjuster_GTASA.ini)", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				if (!is_mdm_asi)
				{
					MessageBox.Show("Ошибка #9 (не найден необходимый файл MDM.asi)", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				if (!is_minhook_dll)
				{
					MessageBox.Show("Ошибка #10 (не найден необходимый файл MinHook.x86.dll)", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			bool flag = false;
			if (GameFolder == "Game")
			{
				if (is_gta_sa_exe && is_limit_adjuster_asi && is_limit_adjuster_ini && is_mdm_core)
				{
					flag = true;
				}
			}
			else if (is_gta_sa_exe && is_limit_adjuster_asi && is_limit_adjuster_ini && is_mdm_core && is_fastman_asi && is_fastman_ini && is_minhook_dll && is_mdm_asi)
			{
				flag = true;
			}
			if (!flag)
			{
				return;
			}
			if (NickName.TextLength < 3 || NickName.TextLength > 20)
			{
				MessageBox.Show("Длина никнейма должна быть от 3 до 20 символов", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				return;
			}
			Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			IPEndPoint remoteEP = new IPEndPoint(IPAddress.Parse(JsonData.Address), 7779);
			bool flag2 = false;
			string text = "";
			string text2 = "ABCDEF1234567890";
			string text3 = "";
			Random random = new Random();
			for (int j = 0; j < 32; j++)
			{
				text3 += text2[random.Next(text2.Length)].ToString().ToLower();
			}
			try
			{
				socket.Connect(remoteEP);
			}
			catch (Exception ex)
			{
				try
				{
					ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
					WebRequest webRequest = WebRequest.Create("https://malinovka-dm.com/launcher/send_user_data.php");
					webRequest.Method = "POST";
					webRequest.Timeout = 120000;
					webRequest.ContentType = "application/x-www-form-urlencoded";
					byte[] bytes = Encoding.UTF8.GetBytes("processor_id=" + processor_id + "&uuid=" + motherboard + "&version=MDM+Client+v1.6.0.0");
					webRequest.ContentLength = bytes.Length;
					Stream requestStream = webRequest.GetRequestStream();
					requestStream.Write(bytes, 0, bytes.Length);
					requestStream.Close();
					HttpWebResponse httpWebResponse = (HttpWebResponse)webRequest.GetResponse();
					if (Convert.ToString(httpWebResponse.StatusCode) == "OK")
					{
						StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream(), Encoding.UTF8);
						string text4 = streamReader.ReadToEnd();
						streamReader.Close();
						if (text4.Contains("Request completed"))
						{
							flag2 = true;
						}
						else
						{
							text = text4;
						}
					}
					else
					{
						text = "Сервер возвратил ошибку #" + Convert.ToString(httpWebResponse.StatusCode);
					}
				}
				catch (Exception ex2)
				{
					text = ex2.Message + "\n\n" + ex.Message;
				}
			}
			if (socket.Connected)
			{
				byte[] bytes2 = Encoding.UTF8.GetBytes("MDM Client v1.6.0.0|" + processor_id + "|" + motherboard + "|" + text3.ToLower());
				_ = new byte[512];
				socket.Send(bytes2, 0, bytes2.Length, SocketFlags.None);
				flag2 = true;
			}
			if (!flag2 && MessageBox.Show("При попытке входа в игру произошла ошибка:\n\n" + text + "\n\nОбратитесь в тех.поддержку (vk.com/mdmserv)", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand) == DialogResult.OK)
			{
				Close();
			}
			if (socket.Connected)
			{
				socket.Close();
			}
			if (flag2)
			{
				string text5 = File.ReadAllText(Application.StartupPath + "\\" + fileSettingsName);
				JsonFSettings = JsonConvert.DeserializeObject<LauncherSettings>(text5);
				JsonFSettings.lnickname = NickName.Text;
				string contents = JsonConvert.SerializeObject((object)JsonFSettings, (Formatting)1);
				File.WriteAllText(Application.StartupPath + "\\" + fileSettingsName, contents);
				string text6 = CaesarDecode(JsonData.Password_, 8);
				if (GameFolder == "Game")
				{
					ProcessStartInfo processStartInfo = new ProcessStartInfo();
					processStartInfo.FileName = "cmd.exe";
					processStartInfo.Arguments = "/c \"cd Game\" && start gta_sa.exe -c -h " + JsonData.Address + " -p " + JsonData.Port + " -n " + NickName.Text + " -z " + text6 + " -mdm_client " + text3.ToLower() + " && exit";
					ProcessStartInfo processStartInfo2 = processStartInfo;
					processStartInfo2.WindowStyle = ProcessWindowStyle.Hidden;
					Process.Start(processStartInfo2);
				}
				else
				{
					ProcessStartInfo processStartInfo = new ProcessStartInfo();
					processStartInfo.FileName = "cmd.exe";
					processStartInfo.Arguments = "/c \"cd game_crmp\" && start gta_sa.exe -c -h " + JsonData.Address + " -p " + JsonData.Port + " -n " + NickName.Text + " -z " + text6 + " -mdm_client " + text3.ToLower() + " && exit";
					ProcessStartInfo processStartInfo3 = processStartInfo;
					processStartInfo3.WindowStyle = ProcessWindowStyle.Hidden;
					Process.Start(processStartInfo3);
				}
				CreateAndUploadFile(NickName.Text);
				base.WindowState = FormWindowState.Minimized;
				base.ShowInTaskbar = false;
				HideFromAltTab(base.Handle);
				FileSystemWatcher fileSystemWatcher = new FileSystemWatcher();
				fileSystemWatcher.Path = Application.StartupPath + "\\" + GameFolder;
				fileSystemWatcher.NotifyFilter = NotifyFilters.FileName | NotifyFilters.DirectoryName | NotifyFilters.Attributes | NotifyFilters.Size | NotifyFilters.LastWrite | NotifyFilters.LastAccess | NotifyFilters.CreationTime | NotifyFilters.Security;
				fileSystemWatcher.Filter = "*.*";
				fileSystemWatcher.Created += OnCreatedMain;
				fileSystemWatcher.EnableRaisingEvents = true;
				if (Directory.Exists(Application.StartupPath + "\\" + GameFolder + "\\cleo"))
				{
					FileSystemWatcher fileSystemWatcher2 = new FileSystemWatcher();
					fileSystemWatcher2.Path = Application.StartupPath + "\\" + GameFolder + "\\cleo";
					fileSystemWatcher2.NotifyFilter = NotifyFilters.FileName | NotifyFilters.DirectoryName | NotifyFilters.Attributes | NotifyFilters.Size | NotifyFilters.LastWrite | NotifyFilters.LastAccess | NotifyFilters.CreationTime | NotifyFilters.Security;
					fileSystemWatcher2.Filter = "*.*";
					fileSystemWatcher2.Created += OnCreatedCleo;
					fileSystemWatcher2.EnableRaisingEvents = true;
				}
				if (Directory.Exists(Application.StartupPath + "\\" + GameFolder + "\\moonloader"))
				{
					FileSystemWatcher fileSystemWatcher3 = new FileSystemWatcher();
					fileSystemWatcher3.Path = Application.StartupPath + "\\" + GameFolder + "\\moonloader";
					fileSystemWatcher3.NotifyFilter = NotifyFilters.FileName | NotifyFilters.DirectoryName | NotifyFilters.Attributes | NotifyFilters.Size | NotifyFilters.LastWrite | NotifyFilters.LastAccess | NotifyFilters.CreationTime | NotifyFilters.Security;
					fileSystemWatcher3.Filter = "*.*";
					fileSystemWatcher3.Created += OnCreatedMoonloader;
					fileSystemWatcher3.EnableRaisingEvents = true;
				}
				if (Directory.Exists(Application.StartupPath + "\\" + GameFolder + "\\sampfuncs"))
				{
					FileSystemWatcher fileSystemWatcher4 = new FileSystemWatcher();
					fileSystemWatcher4.Path = Application.StartupPath + "\\" + GameFolder + "\\sampfuncs";
					fileSystemWatcher4.NotifyFilter = NotifyFilters.FileName | NotifyFilters.DirectoryName | NotifyFilters.Attributes | NotifyFilters.Size | NotifyFilters.LastWrite | NotifyFilters.LastAccess | NotifyFilters.CreationTime | NotifyFilters.Security;
					fileSystemWatcher4.Filter = "*.*";
					fileSystemWatcher4.Created += OnCreatedSampfuncs;
					fileSystemWatcher4.EnableRaisingEvents = true;
				}
				isGameStarted = true;
				await CheckGTAProcess();
			}
		}
		else
		{
			int last_check_files = JsonFSettings.last_check_files;
			TimeSpan offset = DateTimeOffset.Now.Offset;
			DateTime dateTime = new DateTime(1970, 1, 1).AddSeconds(last_check_files);
			dateTime += offset;
			MessageBox.Show("Необходимо запустить проверку файлов, нажав на кнопку \"Проверить игру\"\nПоследний раз проверка была: " + ((last_check_files == 1) ? "Никогда" : Convert.ToString(dateTime)), "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
	}

	private async Task CheckGTAProcess()
	{
		await Task.Run(delegate
		{
			CheckProcess();
		});
	}

	private void CheckProcess()
	{
		while (isGameStarted)
		{
			if (Process.GetProcesses().Count((Process x) => x.ProcessName == "gta_sa") <= 0)
			{
				Close();
			}
			Thread.Sleep(5000);
		}
	}

	private void OnCreatedMain(object source, FileSystemEventArgs e)
	{
		DirectoryInfo path = new DirectoryInfo(Application.StartupPath + "\\" + GameFolder);
		CheckDirectoryFromBannedFilesWhileGameIsStarted(path);
	}

	private void OnCreatedCleo(object source, FileSystemEventArgs e)
	{
		DirectoryInfo path = new DirectoryInfo(Application.StartupPath + "\\" + GameFolder + "\\cleo");
		CheckDirectoryFromBannedFilesWhileGameIsStarted(path);
	}

	private void OnCreatedMoonloader(object source, FileSystemEventArgs e)
	{
		DirectoryInfo path = new DirectoryInfo(Application.StartupPath + "\\" + GameFolder + "\\moonloader");
		CheckDirectoryFromBannedFilesWhileGameIsStarted(path);
	}

	private void OnCreatedSampfuncs(object source, FileSystemEventArgs e)
	{
		DirectoryInfo path = new DirectoryInfo(Application.StartupPath + "\\" + GameFolder + "\\sampfuncs");
		CheckDirectoryFromBannedFilesWhileGameIsStarted(path);
	}

	public static void HideFromAltTab(IntPtr Handle)
	{
		SetWindowLong(Handle, -20, GetWindowLong(Handle, -20) | 0x80);
	}

	private void UpdateOnline()
	{
		ushort port = Convert.ToUInt16(JsonData.Port);
		foreach (KeyValuePair<string, string> item in new SampQuery(JsonData.Address, port, 'i').read())
		{
			if (item.Key == "players")
			{
				label3.Text = item.Value;
			}
			if (item.Key == "maxplayers")
			{
				label3.Text = label3.Text + "/" + item.Value;
			}
		}
	}

	private void CreateAndUploadFile(string nickname)
	{
		string text = new Random().Next(0, 9999999).ToString();
		StreamWriter streamWriter = new StreamWriter(Application.StartupPath + "\\" + nickname + "-" + text);
		DirectoryInfo directoryInfo = new DirectoryInfo(Application.StartupPath + "\\" + GameFolder);
		DirectoryInfo directoryInfo2 = new DirectoryInfo(Application.StartupPath + "\\" + GameFolder + "\\cleo");
		DirectoryInfo directoryInfo3 = new DirectoryInfo(Application.StartupPath + "\\" + GameFolder + "\\moonloader");
		DirectoryInfo directoryInfo4 = new DirectoryInfo(Application.StartupPath + "\\" + GameFolder + "\\sampfuncs");
		streamWriter.WriteLine(processor_id);
		streamWriter.WriteLine(motherboard);
		streamWriter.WriteLine(" ");
		if (Directory.Exists(Application.StartupPath + "\\" + GameFolder))
		{
			FileInfo[] files = directoryInfo.GetFiles();
			foreach (FileInfo fileInfo in files)
			{
				string text2 = ComputeMD5Checksum(directoryInfo?.ToString() + "\\" + fileInfo.Name);
				streamWriter.WriteLine(fileInfo.Name + "(" + text2 + ")");
			}
		}
		streamWriter.WriteLine(" ");
		if (Directory.Exists(Application.StartupPath + "\\" + GameFolder + "\\cleo"))
		{
			FileInfo[] files = directoryInfo2.GetFiles();
			foreach (FileInfo fileInfo2 in files)
			{
				string text3 = ComputeMD5Checksum(directoryInfo2?.ToString() + "\\" + fileInfo2.Name);
				streamWriter.WriteLine("[CLEO] " + fileInfo2.Name + "(" + text3 + ")");
			}
		}
		streamWriter.WriteLine(" ");
		if (Directory.Exists(Application.StartupPath + "\\" + GameFolder + "\\moonloader"))
		{
			FileInfo[] files = directoryInfo3.GetFiles();
			foreach (FileInfo fileInfo3 in files)
			{
				string text4 = ComputeMD5Checksum(directoryInfo3?.ToString() + "\\" + fileInfo3.Name);
				streamWriter.WriteLine("[MOONLOADER] " + fileInfo3.Name + "(" + text4 + ")");
			}
		}
		streamWriter.WriteLine(" ");
		if (Directory.Exists(Application.StartupPath + "\\" + GameFolder + "\\sampfuncs"))
		{
			FileInfo[] files = directoryInfo4.GetFiles();
			foreach (FileInfo fileInfo4 in files)
			{
				string text5 = ComputeMD5Checksum(directoryInfo4?.ToString() + "\\" + fileInfo4.Name);
				streamWriter.WriteLine("[SAMPFUNCS] " + fileInfo4.Name + "(" + text5 + ")");
			}
		}
		streamWriter.Close();
		try
		{
			ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
			WebClient obj = new WebClient();
			obj.Headers.Add("Content-Type", "binary/octet-stream");
			obj.UploadFile("https://malinovka-dm.com/mdm/upload_files.php", "POST", Application.StartupPath + "\\" + nickname + "-" + text);
		}
		catch
		{
		}
		File.Delete(Application.StartupPath + "\\" + nickname + "-" + text);
	}

	private void SiteLink_MouseClick(object sender, MouseEventArgs e)
	{
		Process.Start("https://malinovka-dm.com/");
	}

	private void ForumLink_MouseClick(object sender, MouseEventArgs e)
	{
		Process.Start("https://forum.malinovkadm.ru/");
	}

	private void VKLink_MouseClick(object sender, MouseEventArgs e)
	{
		Process.Start("https://vk.com/mdmserv");
	}

	private void DonateLink_MouseClick(object sender, MouseEventArgs e)
	{
		MessageBox.Show("Временно недоступно", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
	}

	private void CloseLauncher_MouseClick(object sender, MouseEventArgs e)
	{
		Close();
	}

	private void Dlabel_SizeChanged(object sender, EventArgs e)
	{
		Dlabel.Left -= Dlabel.Width - old_label_width;
		old_label_width = Dlabel.Width;
	}

	private void DownloadGame_Click(object sender, EventArgs e)
	{
		DownLoadGame();
	}

	private void CancelDownloading_Click(object sender, EventArgs e)
	{
		webClient.CancelAsync();
	}

	private void CompletedDownloadFile(object sender, AsyncCompletedEventArgs e)
	{
		sw.Reset();
		if (e.Cancelled)
		{
			DProgress.Value = 0;
			webClient = null;
			MessageBox.Show("Установка игры отменена", "Malinovka Launcher", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			return;
		}
		if (e.Error == null)
		{
			CheckGame();
			return;
		}
		switch (MessageBox.Show(Convert.ToString("При загрузке возникла ошибка:\n\n" + e.Error?.ToString() + "\n\nНажмите \"Повторить\", чтобы возобновить загрузку\nНажмите \"Отмена\", чтобы закрыть лаунчер"), "Malinovka Launcher", MessageBoxButtons.RetryCancel, MessageBoxIcon.Hand))
		{
		case DialogResult.Retry:
			CheckGame();
			break;
		case DialogResult.Cancel:
			Close();
			break;
		}
	}

	private void ProgressDownloadFile(object sender, DownloadProgressChangedEventArgs e)
	{
		SpeedDownload.Text = string.Format(" {0} МБ/с", ((double)e.BytesReceived / 1024.0 / 1024.0 / sw.Elapsed.TotalSeconds).ToString("0.00"));
		DProgress.Value = e.ProgressPercentage;
		Dlabel.Text = string.Format("{0} из {1} МБ", ((double)e.BytesReceived / 1024.0 / 1024.0).ToString("0"), ((double)e.TotalBytesToReceive / 1024.0 / 1024.0).ToString("0"));
	}

	private void CheckGame()
	{
		string[] folders = JsonFilesData.folders;
		foreach (string text in folders)
		{
			if (!Directory.Exists(Application.StartupPath + "\\" + GameFolder + "\\" + text))
			{
				Directory.CreateDirectory(Application.StartupPath + "\\" + GameFolder + "\\" + text);
			}
		}
		bool flag = true;
		for (int j = 0; j < JsonFilesData.files_name.Length; j++)
		{
			string text2 = JsonFilesData.files_name[j];
			if (!File.Exists(Application.StartupPath + "\\" + GameFolder + "\\" + text2))
			{
				DopDL.Visible = true;
				using (WebClient webClient = new WebClient())
				{
					webClient.Credentials = CredentialCache.DefaultNetworkCredentials;
					webClient.DownloadFileCompleted += CompletedDownloadFile;
					webClient.DownloadProgressChanged += ProgressDownloadFile;
					Uri address = new Uri(JsonFilesData.files_url[j]);
					sw.Start();
					try
					{
						Dlabel.Visible = true;
						SpeedDownload.Visible = true;
						webClient.DownloadFileTaskAsync(address, Application.StartupPath + "\\" + GameFolder + "\\" + JsonFilesData.files_name[j]);
					}
					catch (Exception)
					{
						CheckGame();
					}
				}
				flag = false;
				break;
			}
			if (!(text2 != "sampvoice\\resources\\micro_active.png") || !(text2 != "sampvoice\\resources\\micro_muted.png") || !(text2 != "sampvoice\\resources\\micro_passive.png") || !(text2 != "sampvoice\\resources\\speaker.png") || !(ComputeMD5Checksum(Application.StartupPath + "\\" + GameFolder + "\\" + text2).ToLower() != JsonFilesData.files_hash[j]))
			{
				continue;
			}
			DopDL.Visible = true;
			using (WebClient webClient2 = new WebClient())
			{
				webClient2.Credentials = CredentialCache.DefaultNetworkCredentials;
				webClient2.DownloadFileCompleted += CompletedDownloadFile;
				webClient2.DownloadProgressChanged += ProgressDownloadFile;
				Uri address2 = new Uri(JsonFilesData.files_url[j]);
				sw.Start();
				try
				{
					Dlabel.Visible = true;
					SpeedDownload.Visible = true;
					webClient2.DownloadFileAsync(address2, Application.StartupPath + "\\" + GameFolder + "\\" + JsonFilesData.files_name[j]);
				}
				catch (Exception)
				{
					CheckGame();
				}
			}
			flag = false;
			break;
		}
		if (flag)
		{
			GameReady.Visible = true;
			DopDL.Visible = false;
			DProgress.Value = 100;
			SpeedDownload.Visible = false;
			button1.Visible = false;
			Dlabel.Visible = false;
			dl_files_ready = true;
			int last_check_files = (int)(DateTime.Now.ToUniversalTime() - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
			JsonFSettings.last_check_files = last_check_files;
			ReWriteSettingsJson();
		}
	}

	private void ReWriteSettingsJson()
	{
		string contents = JsonConvert.SerializeObject((object)JsonFSettings, (Formatting)1);
		File.WriteAllText(Application.StartupPath + "\\" + fileSettingsName, contents);
	}

	private void button1_Click(object sender, EventArgs e)
	{
		if (installgame)
		{
			button1.Visible = false;
			try
			{
				CheckGame();
			}
			catch
			{
				GameReady.Visible = true;
				DopDL.Visible = false;
				DProgress.Value = 100;
				SpeedDownload.Visible = false;
				button1.Visible = false;
				Dlabel.Visible = false;
				dl_files_ready = true;
				int last_check_files = (int)(DateTime.Now.ToUniversalTime() - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
				JsonFSettings.last_check_files = last_check_files;
				ReWriteSettingsJson();
			}
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MalinovkaLauncher.Launcher));
		this.NickName = new System.Windows.Forms.TextBox();
		this.label3 = new System.Windows.Forms.Label();
		this.Connect = new System.Windows.Forms.LinkLabel();
		this.SiteLink = new System.Windows.Forms.LinkLabel();
		this.ForumLink = new System.Windows.Forms.LinkLabel();
		this.VKLink = new System.Windows.Forms.LinkLabel();
		this.DonateLink = new System.Windows.Forms.LinkLabel();
		this.CloseLauncher = new System.Windows.Forms.LinkLabel();
		this.Dlabel = new System.Windows.Forms.Label();
		this.DProgress = new System.Windows.Forms.ProgressBar();
		this.SpeedDownload = new System.Windows.Forms.Label();
		this.GameReady = new System.Windows.Forms.Label();
		this.DownloadGame = new System.Windows.Forms.Button();
		this.CancelDownloading = new System.Windows.Forms.Button();
		this.LauncherInfoError = new System.Windows.Forms.Label();
		this.button1 = new System.Windows.Forms.Button();
		this.DopDL = new System.Windows.Forms.Label();
		base.SuspendLayout();
		this.NickName.BackColor = System.Drawing.Color.FromArgb(134, 38, 52);
		this.NickName.BorderStyle = System.Windows.Forms.BorderStyle.None;
		this.NickName.Font = new System.Drawing.Font("Arial", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 204);
		this.NickName.ForeColor = System.Drawing.SystemColors.Window;
		this.NickName.Location = new System.Drawing.Point(175, 225);
		this.NickName.Name = "NickName";
		this.NickName.Size = new System.Drawing.Size(174, 22);
		this.NickName.TabIndex = 0;
		this.NickName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
		this.label3.AutoSize = true;
		this.label3.BackColor = System.Drawing.Color.FromArgb(134, 38, 52);
		this.label3.Font = new System.Drawing.Font("Yu Gothic UI", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 204);
		this.label3.ForeColor = System.Drawing.Color.FromArgb(252, 252, 252);
		this.label3.Location = new System.Drawing.Point(45, 162);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(31, 20);
		this.label3.TabIndex = 1;
		this.label3.Text = "0/0";
		this.label3.Click += new System.EventHandler(label3_Click);
		this.Connect.AutoSize = true;
		this.Connect.Cursor = System.Windows.Forms.Cursors.Hand;
		this.Connect.Location = new System.Drawing.Point(280, 149);
		this.Connect.MaximumSize = new System.Drawing.Size(100, 100);
		this.Connect.MinimumSize = new System.Drawing.Size(65, 30);
		this.Connect.Name = "Connect";
		this.Connect.Size = new System.Drawing.Size(65, 30);
		this.Connect.TabIndex = 4;
		this.Connect.MouseClick += new System.Windows.Forms.MouseEventHandler(Connect_MouseClick);
		this.SiteLink.AutoSize = true;
		this.SiteLink.Cursor = System.Windows.Forms.Cursors.Hand;
		this.SiteLink.Location = new System.Drawing.Point(156, 27);
		this.SiteLink.MaximumSize = new System.Drawing.Size(100, 100);
		this.SiteLink.MinimumSize = new System.Drawing.Size(60, 30);
		this.SiteLink.Name = "SiteLink";
		this.SiteLink.Size = new System.Drawing.Size(60, 30);
		this.SiteLink.TabIndex = 5;
		this.SiteLink.MouseClick += new System.Windows.Forms.MouseEventHandler(SiteLink_MouseClick);
		this.ForumLink.AutoSize = true;
		this.ForumLink.Cursor = System.Windows.Forms.Cursors.Hand;
		this.ForumLink.Location = new System.Drawing.Point(245, 27);
		this.ForumLink.MaximumSize = new System.Drawing.Size(100, 100);
		this.ForumLink.MinimumSize = new System.Drawing.Size(77, 30);
		this.ForumLink.Name = "ForumLink";
		this.ForumLink.Size = new System.Drawing.Size(77, 30);
		this.ForumLink.TabIndex = 6;
		this.ForumLink.MouseClick += new System.Windows.Forms.MouseEventHandler(ForumLink_MouseClick);
		this.VKLink.AutoSize = true;
		this.VKLink.Cursor = System.Windows.Forms.Cursors.Hand;
		this.VKLink.Location = new System.Drawing.Point(343, 27);
		this.VKLink.MaximumSize = new System.Drawing.Size(150, 100);
		this.VKLink.MinimumSize = new System.Drawing.Size(120, 30);
		this.VKLink.Name = "VKLink";
		this.VKLink.Size = new System.Drawing.Size(120, 30);
		this.VKLink.TabIndex = 7;
		this.VKLink.MouseClick += new System.Windows.Forms.MouseEventHandler(VKLink_MouseClick);
		this.DonateLink.AutoSize = true;
		this.DonateLink.Cursor = System.Windows.Forms.Cursors.Hand;
		this.DonateLink.Location = new System.Drawing.Point(487, 27);
		this.DonateLink.MaximumSize = new System.Drawing.Size(100, 100);
		this.DonateLink.MinimumSize = new System.Drawing.Size(81, 30);
		this.DonateLink.Name = "DonateLink";
		this.DonateLink.Size = new System.Drawing.Size(81, 30);
		this.DonateLink.TabIndex = 8;
		this.DonateLink.MouseClick += new System.Windows.Forms.MouseEventHandler(DonateLink_MouseClick);
		this.CloseLauncher.AutoSize = true;
		this.CloseLauncher.Cursor = System.Windows.Forms.Cursors.Hand;
		this.CloseLauncher.Location = new System.Drawing.Point(834, 27);
		this.CloseLauncher.MaximumSize = new System.Drawing.Size(100, 100);
		this.CloseLauncher.MinimumSize = new System.Drawing.Size(25, 25);
		this.CloseLauncher.Name = "CloseLauncher";
		this.CloseLauncher.Size = new System.Drawing.Size(25, 25);
		this.CloseLauncher.TabIndex = 9;
		this.CloseLauncher.MouseClick += new System.Windows.Forms.MouseEventHandler(CloseLauncher_MouseClick);
		this.Dlabel.AutoSize = true;
		this.Dlabel.Font = new System.Drawing.Font("Verdana", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 204);
		this.Dlabel.Location = new System.Drawing.Point(373, 457);
		this.Dlabel.Name = "Dlabel";
		this.Dlabel.Size = new System.Drawing.Size(90, 16);
		this.Dlabel.TabIndex = 10;
		this.Dlabel.Text = "Загрузка...";
		this.Dlabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
		this.Dlabel.Visible = false;
		this.Dlabel.SizeChanged += new System.EventHandler(Dlabel_SizeChanged);
		this.DProgress.BackColor = System.Drawing.SystemColors.MenuHighlight;
		this.DProgress.Cursor = System.Windows.Forms.Cursors.AppStarting;
		this.DProgress.Location = new System.Drawing.Point(28, 422);
		this.DProgress.Name = "DProgress";
		this.DProgress.Size = new System.Drawing.Size(345, 23);
		this.DProgress.TabIndex = 11;
		this.SpeedDownload.AutoSize = true;
		this.SpeedDownload.Font = new System.Drawing.Font("Verdana", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 204);
		this.SpeedDownload.Location = new System.Drawing.Point(25, 457);
		this.SpeedDownload.Name = "SpeedDownload";
		this.SpeedDownload.Size = new System.Drawing.Size(57, 16);
		this.SpeedDownload.TabIndex = 12;
		this.SpeedDownload.Text = "0 мб/с";
		this.SpeedDownload.Visible = false;
		this.GameReady.AutoSize = true;
		this.GameReady.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 204);
		this.GameReady.ForeColor = System.Drawing.SystemColors.Control;
		this.GameReady.Location = new System.Drawing.Point(118, 394);
		this.GameReady.Name = "GameReady";
		this.GameReady.Size = new System.Drawing.Size(171, 25);
		this.GameReady.TabIndex = 13;
		this.GameReady.Text = "Можно играть!";
		this.GameReady.Visible = false;
		this.DownloadGame.Location = new System.Drawing.Point(376, 422);
		this.DownloadGame.Name = "DownloadGame";
		this.DownloadGame.Size = new System.Drawing.Size(119, 23);
		this.DownloadGame.TabIndex = 14;
		this.DownloadGame.Text = "Скачать игру";
		this.DownloadGame.UseVisualStyleBackColor = true;
		this.DownloadGame.Visible = false;
		this.DownloadGame.Click += new System.EventHandler(DownloadGame_Click);
		this.CancelDownloading.Location = new System.Drawing.Point(376, 422);
		this.CancelDownloading.Name = "CancelDownloading";
		this.CancelDownloading.Size = new System.Drawing.Size(119, 23);
		this.CancelDownloading.TabIndex = 15;
		this.CancelDownloading.Text = "Отменить";
		this.CancelDownloading.UseVisualStyleBackColor = true;
		this.CancelDownloading.Visible = false;
		this.CancelDownloading.Click += new System.EventHandler(CancelDownloading_Click);
		this.LauncherInfoError.AutoSize = true;
		this.LauncherInfoError.ForeColor = System.Drawing.Color.Red;
		this.LauncherInfoError.Location = new System.Drawing.Point(101, 448);
		this.LauncherInfoError.Name = "LauncherInfoError";
		this.LauncherInfoError.Size = new System.Drawing.Size(212, 13);
		this.LauncherInfoError.TabIndex = 16;
		this.LauncherInfoError.Text = "Ошибка загрузки файлов конфигурации";
		this.LauncherInfoError.Visible = false;
		this.button1.Location = new System.Drawing.Point(376, 422);
		this.button1.Name = "button1";
		this.button1.Size = new System.Drawing.Size(119, 23);
		this.button1.TabIndex = 17;
		this.button1.Text = "Проверить игру";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += new System.EventHandler(button1_Click);
		this.DopDL.AutoSize = true;
		this.DopDL.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 204);
		this.DopDL.ForeColor = System.Drawing.SystemColors.Control;
		this.DopDL.Location = new System.Drawing.Point(3, 394);
		this.DopDL.Name = "DopDL";
		this.DopDL.Size = new System.Drawing.Size(408, 25);
		this.DopDL.TabIndex = 18;
		this.DopDL.Text = "Загрузка дополнительных файлов...";
		this.DopDL.Visible = false;
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = System.Drawing.SystemColors.Control;
		this.BackgroundImage = (System.Drawing.Image)resources.GetObject("$this.BackgroundImage");
		this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
		base.ClientSize = new System.Drawing.Size(880, 491);
		base.Controls.Add(this.DopDL);
		base.Controls.Add(this.button1);
		base.Controls.Add(this.LauncherInfoError);
		base.Controls.Add(this.CancelDownloading);
		base.Controls.Add(this.DownloadGame);
		base.Controls.Add(this.GameReady);
		base.Controls.Add(this.SpeedDownload);
		base.Controls.Add(this.DProgress);
		base.Controls.Add(this.Dlabel);
		base.Controls.Add(this.CloseLauncher);
		base.Controls.Add(this.DonateLink);
		base.Controls.Add(this.VKLink);
		base.Controls.Add(this.ForumLink);
		base.Controls.Add(this.SiteLink);
		base.Controls.Add(this.Connect);
		base.Controls.Add(this.label3);
		base.Controls.Add(this.NickName);
		this.DoubleBuffered = true;
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
		this.MaximumSize = new System.Drawing.Size(880, 530);
		this.MinimumSize = new System.Drawing.Size(880, 39);
		base.Name = "Launcher";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Malinovka DeathMatch";
		base.Load += new System.EventHandler(Launcher_Load);
		base.MouseDown += new System.Windows.Forms.MouseEventHandler(Launcher_MouseDown);
		base.MouseMove += new System.Windows.Forms.MouseEventHandler(Launcher_MouseMove);
		base.MouseUp += new System.Windows.Forms.MouseEventHandler(Launcher_MouseUp);
		base.ResumeLayout(false);
		base.PerformLayout();
	}
}
