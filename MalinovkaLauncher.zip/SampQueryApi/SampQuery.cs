using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace SampQueryApi;

internal class SampQuery
{
	private IPAddress serverIp;

	private IPEndPoint serverEndPoint;

	private Socket svrConnect;

	private string szIP;

	private ushort iPort;

	private bool bDebug;

	private DateTime TransmitMS;

	private DateTime ReceiveMS;

	private Dictionary<string, string> dData = new Dictionary<string, string>();

	public SampQuery(string ip, ushort port, char packet_type, bool console_debug = false)
	{
		MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		try
		{
			serverIp = new IPAddress(IPAddress.Parse(ip).GetAddressBytes());
			serverEndPoint = new IPEndPoint(serverIp, port);
			svrConnect = new Socket(serverEndPoint.AddressFamily, SocketType.Dgram, ProtocolType.Udp);
			svrConnect.SendTimeout = 5000;
			svrConnect.ReceiveTimeout = 5000;
			szIP = ip;
			iPort = port;
			bDebug = console_debug;
			if (bDebug)
			{
				Console.Write("Connecting to " + ip + ":" + port + Environment.NewLine);
			}
			try
			{
				using (memoryStream)
				{
					using (binaryWriter)
					{
						string[] array = szIP.ToString().Split('.');
						binaryWriter.Write("SAMP".ToCharArray());
						binaryWriter.Write(Convert.ToByte(Convert.ToInt16(array[0])));
						binaryWriter.Write(Convert.ToByte(Convert.ToInt16(array[1])));
						binaryWriter.Write(Convert.ToByte(Convert.ToInt16(array[2])));
						binaryWriter.Write(Convert.ToByte(Convert.ToInt16(array[3])));
						binaryWriter.Write(iPort);
						binaryWriter.Write(packet_type);
						if (bDebug)
						{
							Console.Write("Transmitting Packet '" + packet_type + "'" + Environment.NewLine);
						}
						TransmitMS = DateTime.Now;
					}
				}
				svrConnect.SendTo(memoryStream.ToArray(), serverEndPoint);
			}
			catch (Exception arg)
			{
				if (bDebug)
				{
					Console.Write("Failed to receive packet:", arg);
				}
			}
		}
		catch (Exception arg2)
		{
			if (bDebug)
			{
				Console.Write("Failed to connect to IP:", arg2);
			}
		}
	}

	public Dictionary<string, string> read(bool flushdata = true)
	{
		try
		{
			serverIp = new IPAddress(IPAddress.Parse(szIP).GetAddressBytes());
			serverEndPoint = new IPEndPoint(serverIp, iPort);
			EndPoint remoteEP = serverEndPoint;
			byte[] buffer = new byte[2048];
			svrConnect.ReceiveFrom(buffer, ref remoteEP);
			svrConnect.Close();
			ReceiveMS = DateTime.Now;
			if (flushdata)
			{
				dData.Clear();
			}
			string text = ReceiveMS.Subtract(TransmitMS).Milliseconds.ToString();
			MemoryStream memoryStream = new MemoryStream(buffer);
			BinaryReader binaryReader = new BinaryReader(memoryStream);
			using (memoryStream)
			{
				using (binaryReader)
				{
					binaryReader.ReadBytes(10);
					switch (binaryReader.ReadChar())
					{
					case 'i':
						dData.Add("password", Convert.ToString(binaryReader.ReadByte()));
						dData.Add("players", Convert.ToString(binaryReader.ReadInt16()));
						dData.Add("maxplayers", Convert.ToString(binaryReader.ReadInt16()));
						dData.Add("hostname", new string(binaryReader.ReadChars(binaryReader.ReadInt32())));
						dData.Add("gamemode", new string(binaryReader.ReadChars(binaryReader.ReadInt32())));
						dData.Add("mapname", new string(binaryReader.ReadChars(binaryReader.ReadInt32())));
						break;
					case 'r':
					{
						int j = 0;
						for (int num2 = binaryReader.ReadInt16(); j < num2; j++)
						{
							dData.Add(new string(binaryReader.ReadChars(binaryReader.ReadByte())), new string(binaryReader.ReadChars(binaryReader.ReadByte())));
						}
						break;
					}
					case 'c':
					{
						int k = 0;
						for (int num3 = binaryReader.ReadInt16(); k < num3; k++)
						{
							dData.Add(new string(binaryReader.ReadChars(binaryReader.ReadByte())), Convert.ToString(binaryReader.ReadInt32()));
						}
						break;
					}
					case 'd':
					{
						int i = 0;
						for (int num = binaryReader.ReadInt16(); i < num; i++)
						{
							string text2 = Convert.ToString(binaryReader.ReadByte());
							dData.Add(text2 + ".name", new string(binaryReader.ReadChars(binaryReader.ReadByte())));
							dData.Add(text2 + ".score", Convert.ToString(binaryReader.ReadInt32()));
							dData.Add(text2 + ".ping", Convert.ToString(binaryReader.ReadInt32()));
						}
						break;
					}
					case 'p':
						dData.Add("ping", text.ToString());
						break;
					}
				}
			}
		}
		catch (Exception arg)
		{
			if (bDebug)
			{
				Console.Write("There's been a problem reading the data", arg);
			}
		}
		return dData;
	}
}
