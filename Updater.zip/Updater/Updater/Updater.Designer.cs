﻿namespace Updater
{
	// Token: 0x02000002 RID: 2
	public partial class Updater : global::System.Windows.Forms.Form
	{
		// Token: 0x06000005 RID: 5 RVA: 0x000022A8 File Offset: 0x000004A8
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000006 RID: 6 RVA: 0x000022E0 File Offset: 0x000004E0
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Updater.Updater));
			this.progressBar1 = new global::System.Windows.Forms.ProgressBar();
			this.label1 = new global::System.Windows.Forms.Label();
			base.SuspendLayout();
			this.progressBar1.Location = new global::System.Drawing.Point(12, 34);
			this.progressBar1.Name = "progressBar1";
			this.progressBar1.Size = new global::System.Drawing.Size(334, 20);
			this.progressBar1.TabIndex = 0;
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(80, 9);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(111, 13);
			this.label1.TabIndex = 1;
			this.label1.Text = "Поиск обновлений...";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(358, 60);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.progressBar1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Name = "Updater";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Поиск обновлений";
			base.Load += new global::System.EventHandler(this.Updater_Load);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000004 RID: 4
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000005 RID: 5
		private global::System.Windows.Forms.ProgressBar progressBar1;

		// Token: 0x04000006 RID: 6
		private global::System.Windows.Forms.Label label1;
	}
}
