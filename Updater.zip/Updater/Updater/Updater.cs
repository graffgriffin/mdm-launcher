﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace Updater
{
	public partial class Updater : Form
	{
		public Updater()
		{
			this.InitializeComponent();
		}

		private void Updater_Load(object sender, EventArgs e)
		{
			this.processList = Process.GetProcessesByName("MalinovkaLauncher");
			for (int num = 0; num != this.processList.Length; num++)
			{
				this.processList[num].Kill();
			}
			try
			{
				using (WebClient webClient = new WebClient())
				{
					string text = webClient.DownloadString("https://malinovka-dm.com/launcher/launcher.json");
					this.JsonData = JsonConvert.DeserializeObject<Updater.LauncherData>(text);
					bool flag = Convert.ToString(this.VersionLauncher.FileVersion) != this.JsonData.launcher_ver;
					if (flag)
					{
						this.label1.Text = "Установка обновления лаунчера...";
						WebClient webClient2 = new WebClient();
						Uri address = new Uri("https://malinovka-dm.com/download/new/MalinovkaLauncher.exe");
						webClient2.DownloadFileAsync(address, Application.StartupPath + "\\MalinovkaLauncher.exe");
						webClient2.DownloadFileCompleted += this.DownloadUpdate_DownloadFileCompleted1;
						webClient2.DownloadProgressChanged += this.DownloadUpdate_DownloadProgressChanged;
					}
					else
					{
						MessageBox.Show("Обновление не требуется", "Malinovka Updater", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						Process.Start(Application.StartupPath + "\\MalinovkaLauncher.exe");
						base.Close();
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void DownloadUpdate_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
		{
			this.progressBar1.Value = e.ProgressPercentage;
			this.label1.Text = "Установка обновления лаунчера (" + Convert.ToString(e.ProgressPercentage) + "%.)";
		}

		private void DownloadUpdate_DownloadFileCompleted1(object sender, AsyncCompletedEventArgs e)
		{
			bool flag = e.Error == null;
			if (flag)
			{
				MessageBox.Show("Обновление успешно установлено\n\nНажмите \"OK\", чтобы продолжить", "Malinovka Updater", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				Process.Start(Application.StartupPath + "\\MalinovkaLauncher.exe");
				base.Close();
			}
			else
			{
				MessageBox.Show("Произошла ошибка при обновлении:\n\n" + Convert.ToString(e.Error), "Malinovka Updater", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				base.Close();
			}
		}

		protected Process[] processList;

		private FileVersionInfo VersionLauncher = FileVersionInfo.GetVersionInfo(Application.StartupPath + "\\MalinovkaLauncher.exe");

		private Updater.LauncherData JsonData;

		internal class LauncherData
		{
			public string launcher_ver { get; set; }
		}
	}
}