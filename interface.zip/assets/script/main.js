﻿const vO = {
  visible: false,
  weapon: 0,
  ammo: "",
  progress: [{
    id: 1,
    src: "assets/images/hud/mdi_heart.svg",
    color: "#E72020",
    value: 100
  }, {
    id: 2,
    src: "assets/images/hud/mdi_armor.svg",
    color: "#E7E7E7",
    value: 100
  }, {
    id: 3,
    src: "assets/images/hud/mdi_stamina.svg",
    color: "#51B830",
    value: 100
  }],
  money: 0,
  online: 0,
  playerid: 0,
  time: "12:52",
  date: "05.12.2024"
};
const vO2 = {
  visible: false,
  speed: 0,
  health: 0
};
const vO3 = {
  visible: false,
  escapePressed: false,
  items: [],
  taked: false
};
const vO7 = {
  visible: false,
  data: [{
    slot: 1
  }, {
    slot: 2
  }, {
    slot: 3
  }]
};
const vO8 = {
  visible: false,
  data: [{
    id: 1,
    name: "СКИНХЕДЫ",
    score: 52
  }, {
    id: 2,
    name: "ГОПОТА",
    score: 8
  }],
  time: null,
  formattedTime: "00:00",
  info: ""
};
const vO9 = {
  hud: vO,
  speedometer: vO2,
  bookmark: vO3,
  timerNotification: {
    notifications: []
  },
  mainNotification: {
    notifications: [],
    IdCounter: 0
  },
  offerNotification: {
    timer: null,
    remainingTime: 0,
    circumference: 94.2,
    notifications: []
  },
  time: vO7,
  windowMessage: {
    messages: [],
    IdCounter: 0
  },
  capture: vO8
};
var v = new Vue({
  el: ".cef-studio-interface",
  data: vO9,
  created() {
    cef.emit("game:hud:setComponentVisible", "interface", false);
    cef.emit("game:data:pollPlayerStats", true, 50);
    cef.on("game:data:playerStats", (p, p2, p3, p4, p85, p86, p87, p88, p89, p90) => {
      if (this.getInterface("hud")) {
        const vO10 = {
          id: 2,
          value: p3
        };
        this.updateHudProgress(vO10);
        this.updateInterface("hud", "money", p89);
        this.updateInterface("hud", "weapon", p86);
        this.updateInterface("hud", "ammo", p87 + "/" + (p88 - p87));
      }
      if (this.getInterface("speedometer")) {
        this.updateSpeed(p90);
      }
    });
  },
  mounted() {
    window.addEventListener("keydown", this.keyDownHandler);
  },
  computed: {
    timerOffset() {
      return this.circumference - this.remainingTime / this.notification.time * this.circumference;
    },
    position() {
      if (this.getInterface("speedometer")) {
        return "displayed-speedometer";
      }
    },
    formattedCaptureTime: function () {
      const v2 = Math.floor(this.capture.time / 60);
      const v3 = this.capture.time % 60;
      return v2.toString().padStart(2, "0") + ":" + v3.toString().padStart(2, "0");
    }
  },
  methods: {
    keyDownHandler(p91) {
      if (p91.keyCode === 27) {
        if (this.getInterface("bookmark")) {
          if (!this.bookmark.taked) {
            if (!this.bookmark.escapePressed) {
              this.bookmark.escapePressed = true;
              this.sendWindowMessage("Вы не забрали один или несколько предметов!\t При закрытии окна они пропадут!", 5);
            } else {
              this.hideBookmarkMenu();
            }
          } else {
            this.hideBookmarkMenu();
          }
        }
      }
    },
    visibleComponent(p92, p93) {
      const vO11 = {
        hud: this.hud,
        speedometer: this.speedometer,
        bookmark: this.bookmark
      };
      const vVO11 = vO11;
      const v4 = vVO11[p92];
      if (v4) {
        if (p92 === "speedometer" && !p93) {
          document.getElementById("speedometer").style.animation = "fadeOut 0.2s forwards";
          setTimeout(() => v4.visible = false, 200);
        } else if (p92 === "hud" && !p93) {
          document.getElementById("hud").style.animation = "fadeOut 0.2s forwards";
          setTimeout(() => v4.visible = false, 200);
        } else {
          v4.visible = !!p93;
          if (p92 === "bookmark") {
            this.updateInterface("bookmark", "taked", false);
            cef.set_focus(!!p93);
          }
        }
      }
    },
    getInterface(p94) {
      if (p94 === "offerNotification") {
        return this.offerNotification.notifications.length > 0;
      } else if (p94 === "timerNotification") {
        return this.timerNotification.notifications.length > 0;
      } else if (p94 === "mainNotification") {
        return this.mainNotification.notifications.length > 0;
      } else if (p94 === "windowMessage") {
        return this.windowMessage.messages.length > 0;
      }
      const v5 = "" + p94;
      const v6 = this[v5];
      if (v6) {
        return v6.visible;
      } else {
        return false;
      }
    },
    updateInterface(p95, p96, p97) {
      const vP95 = p95;
      if (this[vP95] && this[vP95].hasOwnProperty(p96)) {
        this[vP95][p96] = p97;
      }
    },
    updateHudProgress(p98) {
      if (this.getInterface("hud")) {
        let v7 = this.hud.progress.find(p99 => p99.id === p98.id);
        if (v7) {
          v7.value = p98.value;
        }
      }
    },
    updateSpeed(p100) {
      if (this.getInterface("speedometer")) {
        let vLN4502 = 450;
        let vLN52 = 5;
        let vLN1252 = 125;
        this.speedometer.speed = Math.round(p100);
        if (p100 >= 0 && p100 <= 60) {
          var v19 = Math.abs(vLN52 - vLN1252 * 2.9);
        }
        if (p100 >= 60 && p100 <= 140) {
          var v19 = Math.abs(vLN52 - vLN1252 * 3);
        }
        if (p100 >= 140 && p100 <= 220) {
          var v19 = Math.abs(vLN52 - vLN1252 * 3.15);
        }
        if (p100 >= 220 && p100 <= 250) {
          var v19 = Math.abs(vLN52 - vLN1252 * 3.13);
        }
        if (p100 >= 250 && p100 <= 290) {
          document.getElementById("arrow").style.transform = "rotate(220deg)";
        }
        if (p100 >= 290 && p100 <= 300) {
          var v19 = Math.abs(vLN52 - vLN1252 * 2.76);
        }
        let v20 = vLN52 + p100 / vLN4502 * v19;
        document.getElementById("arrow").style.transform = "rotate(" + v20 + "deg)";
      }
    },
    updateFuel(p101) {
      if (this.getInterface("speedometer")) {
        var v21 = Math.round(180 / 175 * p101 / 1.05);
        document.getElementById("playerVehicleFuel").style = "stroke-dasharray: " + v21 + "% 500%;";
      }
    },
    format(p102) {
      if (this.getInterface("hud")) {
        var v22 = "" + p102;
        var v68 = v22.replace(/,/g, "");
        var v69 = v68.length;
        var vLN0 = 0;
        for (var vLN04 = 0; vLN04 < v69; vLN04++) {
          if ((v69 - vLN04) % 3 == 0 && vLN04 > 0) {
            v68 = v68.slice(0, vLN04 + vLN0) + " " + v68.slice(vLN04 + vLN0);
            vLN0++;
          }
        }
        return v68;
      }
    },
    setItemToBookmarkMenu(p103, p104, p105) {
      if (this.bookmark.visible) {
        if (this.bookmark.items.length < 3) {
          var v70 = "assets/images/bookmark/image_" + p105;
          const vO12 = {
            slot: p103,
            title: p104,
            src: v70
          };
          this.bookmark.items.push(vO12);
        }
      }
    },
    removeItemToBookmarkMenu(p106) {
      this.bookmark.items = this.bookmark.items.filter(p107 => p107.slot !== p106);
    },
    removeAllItemToBookmarkMenu() {
      this.bookmark.items = [];
    },
    takeItemInBookmarkMenu(p108) {
      cef.emit("cefstudio.bookmark:take", p108);
    },
    takeAllItemsInBookmarkMenu() {
      cef.emit("cefstudio.bookmark:takeall");
    },
    hideBookmarkMenu() {
      document.getElementById("bookmark").style.animation = "fadeOut 0.3s forwards";
      setTimeout(() => this.visibleComponent("bookmark", false), this.bookmark.escapePressed = false, 300);
      cef.emit("cefstudio.bookmark:close");
    },
    closeBookmarkMenu() {
      if (!this.bookmark.taked) {
        if (!this.bookmark.escapePressed) {
          this.bookmark.escapePressed = true;
          this.sendWindowMessage("Вы не забрали один или несколько предметов!\t При закрытии окна они пропадут!", 5);
        } else {
          this.hideBookmarkMenu();
        }
      } else {
        this.hideBookmarkMenu();
      }
    },
    setBookmarkDELETE(p109, p110) {
      const vLSAssetsimagesbookmark2 = "assets/images/bookmark/image_";
      p110 = p110.map(p111 => {
        return {
          ...p111,
          src: "" + (vLSAssetsimagesbookmark2 + p111.src)
        };
      });
      this.bookmark.items = p110;
      this.bookmark.visible = !!p109;
      cef.set_focus(!!p109);
    },
    replaceColors(p112) {
      return p112.replace(/\{([0-9A-Fa-f]{6})\}/g, "<span style=\"color: #$1;\">").replace(/\{\/\}/g, "</span>");
    },
    formatTime(p113) {
      const v71 = Math.floor(p113 / 60);
      const v72 = p113 % 60;
      return v71 + ":" + v72.toString().padStart(2, "0");
    },
    sendTimerNotification(p114, p115, p116) {
      var v73 = p116.replace(/\t/g, "<br>");
      const v74 = this.replaceColors(v73);
      if (this.timerNotification.notifications.length < 4) {
        const vO14 = {
          id: p114,
          color: p115,
          message: v74
        };
        const vVO14 = vO14;
        this.timerNotification.notifications.push(vVO14);
      }
    },
    setTimeForTimer(p117, p118) {
      const v75 = this.timerNotification.notifications.find(p119 => p119.id === p117);
      if (v75) {
        v75.time = p118;
        v75.timer = this.formatTime(p118);
        if (p118 <= 0) {
          clearInterval(v75.interval);
          const v76 = document.getElementById("timerNotification-" + v75.id);
          if (v76) {
            v76.style.animation = "transform2FadeOut 0.6s forwards";
            setTimeout(() => this.removeTimerNotification(v75.id), 600);
          }
        }
      }
    },
    removeTimerNotification(p120) {
      this.timerNotification.notifications = this.timerNotification.notifications.filter(p121 => {
        if (p121.id === p120) {
          if (p121.interval) {
            clearInterval(p121.interval);
            p121.interval = null;
          }
        }
        return p121.id !== p120;
      });
    },
    sendMainNotification(p122, p123, p124) {
      var v77 = p123.replace(/\t/g, "<br>");
      const v78 = this.replaceColors(v77);
      if (this.mainNotification.notifications.length < 4) {
        const v79 = this.mainNotification.IdCounter++;
        const vO15 = {
          id: v79,
          color: p122,
          message: v78,
          remainingTime: p124,
          time: p124
        };
        const vVO15 = vO15;
        this.mainNotification.notifications.push(vVO15);
        const v80 = p124 * 1000;
        const v81 = Date.now();
        vVO15.interval = setInterval(() => {
          const v82 = Date.now() - v81;
          const v83 = Math.max(0, Math.ceil((v80 - v82) / 1000));
          vVO15.remainingTime = v83;
          if (v83 <= 0) {
            clearInterval(vVO15.interval);
            const v84 = document.getElementById("mainNotification-" + v79);
            if (v84) {
              v84.style.animation = "transform1FadeOut 0.3s forwards";
              setTimeout(() => this.removeNotification(v79), 600);
            }
          }
        }, 1000);
      }
    },
    removeNotification(p125) {
      this.mainNotification.notifications = this.mainNotification.notifications.filter(p126 => {
        if (p126.id === p125) {
          if (p126.interval) {
            clearInterval(p126.interval);
            p126.interval = null;
          }
        }
        return p126.id !== p125;
      });
    },
    sendOfferNotification(p127, p128, p129, p130, p131) {
      const vLN12 = 1;
      if (!this.offerNotification.notifications.some(p132 => p132.id === vLN12)) {
        const v85 = p131 * 1000;
        const v86 = Date.now();
        const vSetInterval3 = setInterval(() => {
          const v87 = Date.now() - v86;
          const v88 = Math.max(0, v85 - v87);
          const v89 = v88 / v85 * 282.6;
          const v90 = Math.ceil(v88 / 1000);
          this.offerNotification.notifications = this.offerNotification.notifications.map(p133 => p133.id === vLN12 ? {
            ...p133,
            progress: v89,
            timeLeft: v90
          } : p133);
          if (v88 <= 0) {
            const v91 = document.getElementById("offer-notification");
            clearInterval(vSetInterval3);
            if (v91) {
              v91.style.animation = "transform2FadeOut 0.6s forwards";
              setTimeout(() => this.removeOfferNotification(vLN12), 600);
            }
          }
        }, 100);
        const v92 = this.replaceColors(p128);
        const vO16 = {
          id: vLN12,
          type: p127,
          message: v92,
          button1: p129,
          button2: p130,
          progress: 282.6,
          timeLeft: p131,
          interval: vSetInterval3
        };
        this.offerNotification.notifications.push(vO16);
      }
    },
    removeOfferNotification(p134) {
      const v93 = this.offerNotification.notifications.find(p135 => p135.id === p134);
      if (v93) {
        clearInterval(v93.interval);
      }
      this.offerNotification.notifications = this.offerNotification.notifications.filter(p136 => p136.id !== p134);
    },
    showTime(p137, p138, p139, p140) {
      this.time.visible = true;
      const vO31 = {
        value: p138
      };
      const vO32 = {
        value: p139
      };
      const vO33 = {
        value: p140
      };
      this.time.data = [vO31, vO32, vO33];
      const v94 = p137 * 1000;
      const v95 = Date.now();
      const vSetInterval4 = setInterval(() => {
        const v96 = Date.now() - v95;
        const v97 = Math.max(0, v94 - v96);
        if (v97 <= 0) {
          clearInterval(vSetInterval4);
          const v98 = document.getElementById("time");
          v98.style.animation = "fadeOut 0.2s forwards";
          setTimeout(() => this.time.visible = false, 300);
        }
      }, 100);
    },
    sendWindowMessage(p141, p142) {
      var v99 = p141.replace(/\t/g, "<br>");
      const v100 = this.replaceColors(v99);
      if (this.windowMessage.messages.length < 4) {
        const v101 = this.windowMessage.IdCounter++;
        const vO34 = {
          id: v101,
          message: v100,
          remainingTime: p142,
          time: p142
        };
        const vVO34 = vO34;
        this.windowMessage.messages.push(vVO34);
        const v102 = p142 * 1000;
        const v103 = Date.now();
        vVO34.interval = setInterval(() => {
          const v104 = Date.now() - v103;
          const v105 = Math.max(0, Math.ceil((v102 - v104) / 1000));
          vVO34.remainingTime = v105;
          if (v105 <= 0) {
            clearInterval(vVO34.interval);
            const v106 = document.getElementById("message-" + v101);
            if (v106) {
              v106.style.animation = "transform1FadeOut 0.3s forwards";
              setTimeout(() => this.removeWindowMessage(v101), 600);
            }
          }
        }, 1000);
      }
    },
    removeWindowMessage(p143) {
      this.windowMessage.messages = this.windowMessage.messages.filter(p144 => {
        if (p144.id === p143) {
          if (p144.interval) {
            clearInterval(p144.interval);
            p144.interval = null;
          }
        }
        return p144.id !== p143;
      });
    },
    setCapture(p145, ..._0x416de2) {
      this.capture.visible = p145;
      this.capture.info = "" + _0x416de2;
    },
    updateGang(p146, p147, p148) {
      this.capture.data[p146 - 1].name = p147;
      this.capture.data[p146 - 1].score = p148;
    },
    updateCaptureTime(p149) {
      this.capture.time = p149;
    },
    formatCaptureTime() {
      const v107 = Math.floor(this.capture.time / 60);
      const v108 = this.capture.time % 60;
      this.formattedTime = v107.toString().padStart(2, "0") + ":" + v108.toString().padStart(2, "0");
    },
    updateTimeInHud(p150, p151) {
      this.hud.time = p150;
      this.hud.date = p151;
    }
  }
});
cef.on("cefstudio.malinovkaDM:execute", p152 => eval(p152));
cef.on("CEF:STUDIO:hud:visible", p153 => v.visibleComponent("hud", p153));
cef.on("CEF:STUDIO:hud:update", (p154, p155, p156, p157) => {
  if (v.getInterface("hud")) {
    v.updateInterface("hud", "playerid", p154);
    v.updateInterface("hud", "online", p155);
    const vO35 = {
      id: 3,
      value: p156
    };
    v.updateHudProgress(vO35);
    const vO36 = {
      id: 1,
      value: p157
    };
    v.updateHudProgress(vO36);
  }
});
cef.on("CEF:STUDIO:speed:visible", p158 => v.visibleComponent("speedometer", p158));
cef.on("CEF:STUDIO:speed:health", p159 => v.updateInterface("speedometer", "health", p159));
cef.on("CEF:STUDIO:speed:fuel", p160 => v.updateFuel(p160));